const express = require('express')
const fs = require('fs')
const cors = require('cors')

const app = express()
const port = 3000
app.use(express.static(`${__dirname}/static`))
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

const app2 = express()
const port2 = 5555
app2.use(cors())
app2.use(express.static(`${__dirname}/static`))
app2.listen(port2, () => {
  console.log(`Example app listening on port ${port2}`)
})